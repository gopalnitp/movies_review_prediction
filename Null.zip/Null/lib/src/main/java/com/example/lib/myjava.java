package com.example.lib;

public class myjava {


    public static void main(String[] args) {

        System.out.println("Hello");
    }

}