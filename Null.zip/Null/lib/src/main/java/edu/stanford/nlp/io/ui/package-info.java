/**
 * UI components for I/O operations.
 * @author Huy Nguyen (htnguyen@stanford.edu)
 */
package edu.stanford.nlp.io.ui;