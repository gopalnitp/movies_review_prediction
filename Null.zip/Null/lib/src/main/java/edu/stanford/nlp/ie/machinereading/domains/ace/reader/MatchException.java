
package edu.stanford.nlp.ie.machinereading.domains.ace.reader;

public class MatchException extends RuntimeException {
  public static final long serialVersionUID = 24362462L;

  public MatchException(String m) { super(m); }
}
