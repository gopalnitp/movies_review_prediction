/**
 * A simple directed graph implementatin that we use to support our dependency graphs.
 * We introduced this to avoid needing to depend on an external library for simple graph functionality.
 *
 * @author John Bauer
 */
package edu.stanford.nlp.graph;
