package com.example.lib2;

public class MyClass {
}
